// This service is not used in the current version of the application.
// The app's content is now statically defined in constants.ts.
